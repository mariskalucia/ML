# Mariska de Vries
# 223751

import sys
import random

# Hij opend de file klas.txt
namen = open("D:\Sofware dv\Beginner\Opdrachten\klas.txt")
# Hij leest de namen in 
bestand = namen.read()
# Hij telt de namen bijelkaar op
lists = bestand.split("\n")

# Hij opend de file groepjes.txt 
sys.stdout = open("D:\Sofware dv\Beginner\Opdrachten\groepjes.txt", "w")# En er kan in worden geschreven

# Hij begint bij groep 1
groep = 1
# Er worden 5 personen bij in de groep gezet
aantalklasgenoten = 5

# Hij haalt alle namen uit de lijst weg
for list in lists[:]:
    # Hij stopt met namen er in te zetten als er er 5 inzitten
    if aantalklasgenoten == 5:
        # Hij print De groep en plaats telkens in de {1} {2} {3} enz.
        print("Groep {}:".format(groep))# Hij zet het onderelkaar neer
        # Hij reset de aantal klasgenoten weer naar 0
        aantalklasgenoten=0
        # De groep word van 1 naar 2 van naar 3 enz.
        groep+=1
    # Hij kiest een random naam uit de list namen
    persoon = random.choice(lists)
    print(persoon) 
    aantalklasgenoten+=1
    # Hij verwijderd de namen die dubble zijn
    lists.remove(str(persoon))
    

# Hij sluit de het bestand met de output erin
sys.stdout.close()

    
     
    